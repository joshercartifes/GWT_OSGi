package com.cartif.gui.autentication.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * Interface that defines the possibles methods to call. It displays the method that the 
 * client interface can invoke. 
 * @author Cartif
 */
@RemoteServiceRelativePath("autentication")
public interface AppService extends RemoteService {
	int getUser(String user, String pass) throws Exception;
	String getSession();
}
