package com.cartif.gui.autentication.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface AppServiceAsync {
	void getUser(String user, String pass, AsyncCallback<Integer> callback);

	void getSession(AsyncCallback<String> callback);
}
