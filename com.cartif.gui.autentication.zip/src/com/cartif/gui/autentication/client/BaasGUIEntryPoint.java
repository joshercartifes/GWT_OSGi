package com.cartif.gui.autentication.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class BaasGUIEntryPoint implements EntryPoint {
	/**
	 * Attribute to retains the RPC service to realize asynchronous calls.
	 */
	private final AppServiceAsync gwtService = GWT.create(AppService.class);
	final Label errorLabel = new Label("");
	
	/**
	 * Method calls first time when gwt web application is running. It is the
	 * entry point and draws the main screen. It is composed by user interface
	 * elements as vertical and horizontal panels, buttons, labels, etc. All the
	 * elements are wrapped into a dock panel that is added in root panel. Also,
	 * the event handlers are defined and the calls are performed. The style of
	 * dock panel is:
	 * 
	 * Title Login: |_______| 
	 * Password |_______| 
	 * Button 
	 * ErrorLabel
	 */

	public void onModuleLoad() {
		RootPanel.get().setStyleName("RootPanel");
		DockLayoutPanel layoutPanel = new DockLayoutPanel(Unit.PCT);
		
		//Pop up panel for the image of the wait response
		final PopupPanel waitPanel = new PopupPanel();
		Image waitImg = new Image("img/wait.gif");
		waitImg.setSize("300px", "120px");
		waitPanel.add(waitImg);
		
		// Title of the screen
		Label titleLabel = new Label("Write the login and password:");
		titleLabel.setStyleName("gwt-Label");
		layoutPanel.addNorth(titleLabel, 4);

		// Now it is created a vertical panel with the texts of the login and
		// password
		VerticalPanel vertLeftPanel = new VerticalPanel();
		vertLeftPanel.setSpacing(20);
		Label loginLabel = new Label("Login:");
		loginLabel.setStyleName("gwt-Label");
		Label passLabel = new Label("Password:");
		passLabel.setStyleName("gwt-Label");
		vertLeftPanel.add(loginLabel);
		vertLeftPanel.add(passLabel);
		layoutPanel.addWest(vertLeftPanel, 10);
		
		// EastPanel with the image of CARTIF
		Image rightImage = new Image("img/cartif.jpg");
		rightImage.setSize("360px", "225px");
		rightImage.setAltText("Cartif building");
		layoutPanel.addEast(rightImage, 50);

		// The same for the vertical panel on the right side with the text boxes
		VerticalPanel vertRightPanel = new VerticalPanel();
		vertRightPanel.setSpacing(10);
		final TextBox loginField = new TextBox();
		loginField.setText("");
		loginField.setSize("150px", "20px");
		final PasswordTextBox passField = new PasswordTextBox();
		passField.setText("");
		passField.setSize("150px", "20px");
		vertRightPanel.add(loginField);
		vertRightPanel.add(passField);

		// Last, it is added login button to system access
		final Button loginButton = new Button("Login");
		loginButton.setStyleName("sendButton");
		vertRightPanel.add(loginButton);
		vertRightPanel.add(errorLabel);
		errorLabel.setStyleName("serverResponseLabelError");
		//Error label hidden
		errorLabel.setVisible(false);
		layoutPanel.add(vertRightPanel);

		// South panel with the image of Sierra Elvira
		Image southImage = new Image("img/sierra.jpg");
		southImage.setSize("360px", "225px");
		southImage.setAltText("Sierra Elvira building");
		layoutPanel.addSouth(southImage, 50);

		// Attach the LayoutPanel to the RootLayoutPanel. The latter will listen
		// for resize events on the window to ensure that its children are
		// informed of possible size changes.
		RootLayoutPanel rootLayout = RootLayoutPanel.get();
		rootLayout.setStyleName("LayoutPanel");
		rootLayout.add(layoutPanel);

		/**
		 * Handler for the login button. The handlers are performed when it is
		 * pushed click mouse or enter key. Then, it is send the request to
		 * server. The handler implements <code>ClickHandler</code> and
		 * <code>KeyUpHandler</code>.
		 * 
		 * @author Cartif
		 * 
		 */
		class LoginHandler implements ClickHandler, KeyUpHandler {
			/**
			 * Overridden method of <code>ClickHandler</code> interface to
			 * perform an event of click kind.
			 * 
			 * @param event
			 *            Parameter with the event launched.
			 */
			public void onClick(ClickEvent event) {
				try {
					// It is called the method to synchronize with server

					// MOSTRAMOS LA IMAGEN DE "please wait" *******************
					loginField.setEnabled(false);
					passField.setEnabled(false);
					loginButton.setEnabled(false);
					waitPanel.center();
					
					// PROCESAR LOGIN/PSSWD
					procesarAutenticacion();
					
					

				} catch (Exception e) {
					Window.alert("Error" + e.getMessage());

				}
			}

			/**
			 * Overridden method of <code>KeyUpHandler</code> interface to
			 * perform an event of key kind.
			 * 
			 * @param event
			 *            Parameter with the event launched.
			 */
			public void onKeyUp(KeyUpEvent event) {
				if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
					try {
						// MOSTRAMOS LA IMAGEN DE "Please wait"
						loginField.setEnabled(false);
						passField.setEnabled(false);
						loginButton.setEnabled(false);
						waitPanel.center();
						// PROCESAR LOGIN/PSSWD
						procesarAutenticacion();
						
					} catch (Exception e) {
						Window.alert("Error" + e.getMessage());
					}
				}
			}
			
			/**
			 * This method is performed when button events are launched. Then, it is
			 * sent login and password to server to check the user. If the user is
			 * correct it is checked role and shown the proper screen in function of
			 * permissions. If the user is not right, an error message is print.
			 * 
			 * @throws Exception The method throws exception which are caught.
			 */
			private void procesarAutenticacion() throws Exception {

				errorLabel.setText("");
				final String sLogin = loginField.getText();
				String sPass = passField.getValue();
				
				 // Then, we send the input to the server. 
				gwtService.getUser(sLogin, sPass, new AsyncCallback<Integer>() { 
					//There is an error on system.
					@Override
					public void onFailure(Throwable caught) { 
						waitPanel.hide(); 
						loginField.setEnabled(true);
						passField.setEnabled(true);
						loginButton.setEnabled(true);
						
						// Show the RPC error message to the user
						
						Window.alert(caught.getMessage());
						
						errorLabel.setText(caught.getLocalizedMessage()); 
						errorLabel.setVisible(true);
					}
					
					//The call is performed and it is checked the user. 
					@Override
					public void onSuccess(final Integer iPrivileges) {
						waitPanel.hide(); 
						if (iPrivileges > 0) {
							
							gwtService.getSession(new AsyncCallback<String>() {
								@Override
								public void onFailure(Throwable caught) {}

								@Override
								public void onSuccess(String sSession) {
									RootPanel.get("main").clear();
									
									//Para abrir un nuevo html dentro del contexto de la web application
									//Window.Location.replace(GWT.getHostPageBaseURL() + ""); 
									//If the user is login, it is added the application containers. 
									String sHost = Window.Location.getHost(); 
									Window.Location.assign("http://"+sHost+"/baasGUIMonitoring?session="+sSession+"&priv="+iPrivileges*16.24+"&ot=M3aTs6");
								}
							});
							
						} 
						else {
							//If the user does not fit on database, an error message is shown.
							Window.alert("User does not exist or is wrong");
							errorLabel.setText("User does not exist or is wrong");
							errorLabel.setVisible(true); 
							loginField.setEnabled(true);
							passField.setEnabled(true);
							loginButton.setEnabled(true);
						} 
						
					}
				});
			}
		};
		
		loginField.addKeyUpHandler(new LoginHandler());
		passField.addKeyUpHandler(new LoginHandler());
		loginButton.addKeyUpHandler(new LoginHandler());
		loginButton.addClickHandler(new LoginHandler());
		RootPanel.get("main").add(rootLayout);
	}
}
