package com.cartif.gui.autentication.server;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.service.event.EventAdmin;


/**
 * Activator class
 * @author BaaS Developer Team
 * @date 17/03/2014
 */
public class Activator {
	
	private static BundleContext context;
	
	private Autentication_Handler handler = new Autentication_Handler();
	

	/**
	 * Constructor 
	 */
	public Activator() {}
	

	
	/**
	 * To get the context attribute 
	 */
	public static BundleContext getContext(){
		return context;
	}
	
	
	/**
	 * This methods is to start this Activator 
	 */
	public void start(BundleContext context) throws Exception{
		
		this.context = context;
		
		System.out.println("!!!!!!!!!com.cartif.gui.index -> start");		
		System.out.println("!!!!!!!!!com.cartif.gui.index -> context: " + context);
	}

	
	/**
	 * To stop the Activator 
	 */
	public void stop(BundleContext context) throws Exception{
		
		System.out.println("!!!!!!!!!com.cartif.gui.index -> stop");		
		
	}
	

}  // Activator's end
