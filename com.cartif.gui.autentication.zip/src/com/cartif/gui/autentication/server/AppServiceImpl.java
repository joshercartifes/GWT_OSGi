package com.cartif.gui.autentication.server;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cartif.gui.autentication.client.AppService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
public class AppServiceImpl extends RemoteServiceServlet implements AppService {
	private static final long serialVersionUID = 1L;
	String sSession = null;
	
	@Override
	public String getSession() {
		return sSession;
	}

	public void setSession(String session) {
		this.sSession = session;
	}

	/**
	 * Method which overrides the service from the HttpSerlvet objects
	 */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Thread currentThread = Thread.currentThread();
	    ClassLoader oldContextClassLoader = currentThread.getContextClassLoader();
	    currentThread.setContextClassLoader(this.getClass().getClassLoader());
	    super.service(req, resp);
	    currentThread.setContextClassLoader(oldContextClassLoader);
	}
	
	/**
	 * Method received in the server side to perform the check of the user
	 */
	@Override
	public int getUser(String sUser, String sPass) throws Exception {
		Autentication_Handler.getUser(sUser, sPass);
		while(Autentication_Handler.user == null){
			//do nothing
			//waiting for receiving the event with the user logged in
			Thread.sleep(100);
		}
		if(sUser.equals(Autentication_Handler.user.getsNickname())){
			int iPrivileges = Autentication_Handler.user.getiPrivileges();
			Autentication_Handler.user = null;
			
			HttpServletRequest request = this.getThreadLocalRequest();
		    HttpSession session = request. getSession(true);
		    sSession = session.getId();
			
			//Set the sessions in the services
			com.cartif.gui.alarms.server.AppServiceImpl.getHmUser(true).put(sSession, sUser);
			com.cartif.gui.monitoring.server.AppServiceImpl.getHmUser(true).put(sSession, sUser);		
			com.cartif.gui.optimization.server.AppServiceImpl.getHmUser(true).put(sSession, sUser);
			com.cartif.gui.schedulers.server.AppServiceImpl.getHmUser(true).put(sSession, sUser);
			com.cartif.gui.users.server.AppServiceImpl.getHmUser(true).put(sSession, sUser);

			return iPrivileges;
		}
		else
			return 0;
	}
}
