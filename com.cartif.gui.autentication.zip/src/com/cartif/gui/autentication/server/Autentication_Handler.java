package com.cartif.gui.autentication.server;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.service.event.EventHandler;

import com.cartif.gui.autentication.shared.User;

import java.util.HashMap;
import java.util.Map;

public class Autentication_Handler implements EventHandler {
	private static EventAdmin eventAdmin;
	static Map<String, Object> props = null;
	static User user = null;
	//AppServiceImpl appService = null;
	
	/** 
	 * Constructor
	 */
	public Autentication_Handler() {
		props = new HashMap<String, Object>();
		//appService = new AppServiceImpl();
	}
		
	public EventAdmin getEventAdmin() {
		return eventAdmin;
	}

	/**
	 * Method for injecting the Event Admin through the Spring framework
	 * @param eventAdmin
	 */
	public void setEventAdmin(EventAdmin eventAdmin) {
		System.out.println("/////////////////////////////////////////////");
		System.out.println("EVENT ADMIN INJECTED "+eventAdmin);
		System.out.println("/////////////////////////////////////////////");
		this.eventAdmin = eventAdmin;		
	}	
	
	/**
	 * This method is executed when a topic is received
	 * @param event The event received
	 */
	public void handleEvent(Event event){	
		System.out.println("/////////////////////////////////////////////");
		System.out.println("EVENT RECEIVED with topic: " + event.getTopic());
		System.out.println("/////////////////////////////////////////////");
		
		/**********************************************************************
		 * Management of the received event for the privileges of the user
		 *********************************************************************/
		if(event.getTopic().equalsIgnoreCase("org/baas/guiConnector/trigger/privileges")){
			event.getProperty("processId");
			String sUser = (String)event.getProperty("userId");
			int iPrivileges = (Integer)event.getProperty("privileges");
			
			user = new User(sUser, "", iPrivileges, "", "", 0, null);
		}
		
		/**********************************************************************
		 * Management of the received event for the logout of the user
		 *********************************************************************/
		if(event.getTopic().equalsIgnoreCase("org/baas/guiConnector/trigger/logout")){
			event.getProperty("processId");
			String sSession = (String)event.getProperty("session");
			
			//Remove the sessions in the services
			com.cartif.gui.alarms.server.AppServiceImpl.getHmUser(true).remove(sSession);
			com.cartif.gui.monitoring.server.AppServiceImpl.getHmUser(true).remove(sSession);
			com.cartif.gui.optimization.server.AppServiceImpl.getHmUser(true).remove(sSession);
			com.cartif.gui.schedulers.server.AppServiceImpl.getHmUser(true).remove(sSession);	
		}
	}
	
	/**
	 * Method that send the event to the user handler in order to login the user
	 * 
	 * @param sUser Nickname of the user
	 * @param sPass Password of the user
	 */
	public static void getUser(String sUser, String sPass){
		props.clear();
		props.put("procesId", "GUIAutentication");
		props.put("userId", sUser);
		props.put("userPwd", sPass);
		eventAdmin.postEvent(new Event("org/baas/userHandler/trigger/login", props));
	}
	
}  // Autentication_Handler's end
