package com.cartif.gui.autentication.shared;

import java.io.Serializable;
import java.sql.Timestamp;

public class User implements Serializable{
	private static final long serialVersionUID = 1L;
	private String sNickname;
	private String sPassword;
	private int iPrivileges;
	private String sMail;
	private String sCountry;
	private long lPhoneNumber;
	private Timestamp tValidDate;
	
	public String getsNickname() {
		return sNickname;
	}
	public void setsNickname(String sNickname) {
		this.sNickname = sNickname;
	}
	public String getsPassword() {
		return sPassword;
	}
	public void setsPassword(String sPassword) {
		this.sPassword = sPassword;
	}
	public int getiPrivileges() {
		return iPrivileges;
	}
	public void setiPrivileges(int iPrivileges) {
		this.iPrivileges = iPrivileges;
	}
	public String getsMail() {
		return sMail;
	}
	public void setsMail(String sMail) {
		this.sMail = sMail;
	}
	public String getsCountry() {
		return sCountry;
	}
	public void setsCountry(String sCountry) {
		this.sCountry = sCountry;
	}
	public long getlPhoneNumber() {
		return lPhoneNumber;
	}
	public void setlPhoneNumber(long lPhoneNumber) {
		this.lPhoneNumber = lPhoneNumber;
	}
	public Timestamp gettValidDate() {
		return tValidDate;
	}
	public void settValidDate(Timestamp tValidDate) {
		this.tValidDate = tValidDate;
	}
	
	public User(String sNickname, String sPassword, int iPrivileges,
			String sMail, String sCountry, long lPhoneNumber,
			Timestamp tValidDate) {
		super();
		this.sNickname = sNickname;
		this.sPassword = sPassword;
		this.iPrivileges = iPrivileges;
		this.sMail = sMail;
		this.sCountry = sCountry;
		this.lPhoneNumber = lPhoneNumber;
		this.tValidDate = tValidDate;
	}
	
	public User(){
		super();
	}
}
