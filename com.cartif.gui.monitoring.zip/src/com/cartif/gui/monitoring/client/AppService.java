package com.cartif.gui.monitoring.client;

import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * Interface that defines the possibles methods to call. It displays the method that the 
 * client interface can invoke. 
 * @author Cartif
 */
@RemoteServiceRelativePath("monitoring")
public interface AppService extends RemoteService {
	Map<String, Map<String, Map<String, String>>> getData(List<String> lsBuildings) throws Exception;
	Map<String, Map<String, Map<String, Map<String, String>>>> getMonthlyData(List<String> lsBuildings) throws Exception;
	Map<String, Map<String, String>> downloadData(String sDateIni, String sDateFin, List<String> lsSensors, String sBuildingCode) throws Exception;
	String createFile(Map<String, Map<String, String>> result);
	void logout(String sLogin, String sSession);
	Map<String, String> getHmUser();
}
