package com.cartif.gui.monitoring.client;

import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface AppServiceAsync {
	void getData(List<String> lsBuildings, AsyncCallback<Map<String,Map<String, Map<String, String>>>> asyncCallback);
	void getMonthlyData(List<String> lsBuildings, AsyncCallback<Map<String,Map<String, Map<String, Map<String, String>>>>> asyncCallback);
	void downloadData(String sDateIni, String sDateFin, List<String> lsSensors,	String sBuildingCode, AsyncCallback<Map<String, Map<String, String>>> asyncCallback);
	void createFile(Map<String, Map<String, String>> result, AsyncCallback<String> asyncCallback);
	void logout(String sLogin, String sSession, AsyncCallback<Void> callback);
	void getHmUser(AsyncCallback<Map<String, String>> callback);
}
