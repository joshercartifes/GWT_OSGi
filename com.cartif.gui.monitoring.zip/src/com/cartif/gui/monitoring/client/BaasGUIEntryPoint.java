package com.cartif.gui.monitoring.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cartif.gui.monitoring.shared.BuildingCodes;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.CloseEvent;
import com.google.gwt.event.logical.shared.CloseHandler;
import com.google.gwt.user.client.Random;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.Window.ClosingEvent;
import com.google.gwt.user.client.Window.ClosingHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TabLayoutPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DatePicker;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class BaasGUIEntryPoint implements EntryPoint {
	String sLogin = "";
	String sSession = "";
	
	/**
	 * Attribute to retains the RPC service to realize asynchronous calls.
	 */
	private final AppServiceAsync gwtService = GWT.create(AppService.class);
	Map<String,Map<String,String>> hmTucData = null;
	Map<String,Map<String,String>> hmCartifData = null;
	Map<String,Map<String,String>> hmZubData = null;
	//Map<String,Map<String,String>> hmHusaData = null;
	Map<String,Map<String,String>> hmSierraData = null;
	
	Map<String,Map<String,Map<String,String>>> hmMonthTucData = null;
	Map<String,Map<String,Map<String,String>>> hmMonthCartifData = null;
	Map<String,Map<String,Map<String,String>>> hmMonthZubData = null;
	//Map<String,Map<String,Map<String,String>>> hmMonthHusaData = null;
	Map<String,Map<String,Map<String,String>>> hmMonthSierraData= null;

	
	PrintScreen printScreen = new PrintScreen();
	List<String> lsBuildings;
	
	int iPrivileges = 0;

	/**
	 * Method calls first time when gwt web application is running. It is the
	 * entry point and draws the main screen of the monitoring service. Then, at
	 * the beginning, it gets the information needed for printing the screen. When
	 * received, it is drawn the screen.
	 */

	public void onModuleLoad() {	
		//Gets the buildings of the system
		BuildingCodes.getInstance();
		lsBuildings = BuildingCodes.getlBuildings();
		
		Window.addCloseHandler(new CloseHandler<Window>() {
			@Override
			public void onClose(CloseEvent<Window> event) {
				gwtService.logout(sLogin, sSession, new AsyncCallback<Void>() {
					@Override
					public void onFailure(Throwable caught) {}

					@Override
					public void onSuccess(Void result) {}
				});	
			}
		});
		
		Window.addWindowClosingHandler(new ClosingHandler() {
			@Override
			public void onWindowClosing(ClosingEvent event) {
				gwtService.logout(sLogin, sSession, new AsyncCallback<Void>() {
					@Override
					public void onFailure(Throwable caught) {}

					@Override
					public void onSuccess(Void result) {}
				});	
			}
		});
		
		/*
		 * Getting the privileges of the system and, in function of this value, it is
		 * filtered the information available
		 * 1 - Administrator
		 * 2 - BaaS user
		 * 3 - External user
		 */
		sSession = Window.Location.getParameter("session");
		
		Double dPriv = Double.parseDouble(Window.Location.getParameter("priv"));
		
		if(dPriv / 16.24 == 1 || dPriv / 16.24 == 2 || dPriv / 16.24 == 3){
			Double dPrivileges = dPriv/16.24;
						
			if(dPrivileges % 1 == 0)
				iPrivileges = dPrivileges.intValue();
			
		}
		
		gwtService.getHmUser(new AsyncCallback<Map<String,String>>() {
			@Override
			public void onFailure(Throwable caught) {}

			@Override
			public void onSuccess(final Map<String,String> hmUsers) {				
				if(hmUsers.get(sSession) != null){
					sLogin = hmUsers.get(sSession);
		
					if(iPrivileges > 0){
						/*
						 * For each building, it is got and filled the map of data to be shown
						 */
						
						gwtService.getData(lsBuildings, new AsyncCallback<Map<String,Map<String, Map<String, String>>>>() {
							@Override
							public void onSuccess(Map<String,Map<String, Map<String, String>>> result) {
								
								hmTucData = new HashMap<String,Map<String,String>>();
								hmTucData.putAll(result.get("TUC"));
							
								hmCartifData = new HashMap<String,Map<String,String>>();
								hmCartifData.putAll(result.get("CARTIF"));
									
								hmZubData = new HashMap<String,Map<String,String>>();
								hmZubData.putAll(result.get("ZUB"));
									
								hmSierraData = new HashMap<String,Map<String,String>>();
								hmSierraData.putAll(result.get("SIERRA"));
									
								
								/*
								 * When all the information is fixed, then the panels are printed out.
								 */
								if(hmTucData != null && hmCartifData != null && hmZubData != null &&
									/*hmHusaData.size() > 0 &&*/ hmSierraData != null){					
									
//									retrieveMonthlyData();
									
									hmMonthTucData = new HashMap<String,Map<String,Map<String,String>>>();
									hmMonthCartifData = new HashMap<String,Map<String,Map<String,String>>>();				
									hmMonthZubData = new HashMap<String,Map<String,Map<String,String>>>();								
									hmMonthSierraData= new HashMap<String,Map<String,Map<String,String>>>();
									printPanels();
								}
							}
							@Override
							public void onFailure(Throwable caught) {
								Window.alert("Error getting data from the buildings\n"+	caught.getMessage());
								caught.printStackTrace();					
							}
						});
					}
					else
						Window.alert("Unparseable URL");
				}
				else
					Window.alert("Session is not active");
			}
					
		});
	}
	
	/**
	 * Method which retrieves the monthly information associated to the zones and sensors in
	 * this zone.
	 */
	public void retrieveMonthlyData(){
		//Gets the buildings of the system
		//BuildingCodes.getInstance();
		lsBuildings = BuildingCodes.getlBuildings();
		/*
		 * For each building, it is got and filled the map of data to be shown
		 */
		gwtService.getMonthlyData(lsBuildings, new AsyncCallback<Map<String,Map<String, Map<String, Map<String, String>>>>>() {
			@Override
			public void onFailure(Throwable caught) {
				Window.alert("Error getting monthly data from the buildings");
				caught.printStackTrace();					
			}
			
			@Override
			public void onSuccess(Map<String,Map<String, Map<String, Map<String, String>>>> result) {		
				
				//It is put the maps retrieved with the data of the buildings
				hmMonthTucData = new HashMap<String,Map<String,Map<String,String>>>();
				hmMonthTucData.putAll(result.get("TUC"));

				hmMonthCartifData = new HashMap<String,Map<String,Map<String,String>>>();
				hmMonthCartifData.putAll(result.get("CARTIF"));
				
				hmMonthZubData = new HashMap<String,Map<String,Map<String,String>>>();
				hmMonthZubData.putAll(result.get("ZUB"));
				
				hmMonthSierraData= new HashMap<String,Map<String,Map<String,String>>>();
				hmMonthSierraData.putAll(result.get("SIERRA"));
				
				/*
			 	* When all the information is fixed, then the panels are printed out.
			 	*/
				if(hmMonthTucData != null && hmMonthCartifData != null && hmMonthZubData != null &&
						/*hmMonthHusaData.size() > 0 &&*/ hmMonthSierraData != null){
					printPanels();
				}
			}
		});	
	}
	
	/**
	 * Method that prints the common panels of the GUI. It dispatches the request to the
	 * class PrintScreen
	 */
	public void printPanels(){
		final String sHost = Window.Location.getHost(); 
		// Attach the LayoutPanel to the RootLayoutPanel. The latter will listen
		// for resize events on the window to ensure that its children are
		// informed of possible size changes.
		final RootLayoutPanel rootLayout = RootLayoutPanel.get();
		rootLayout.clear();
		rootLayout.setStyleName("RootLayoutPanel");
		
		//Style for the global panel
		RootPanel.get().setStyleName("RootPanel");

		/*
		 * VerticalPanel for including all the information in the screen
		 */ 
		final VerticalPanel mainVerticalPanel = new VerticalPanel();
		mainVerticalPanel.setSpacing(10);
		
		/*
		 * HorizontalPanel for including the buttons of the functionality
		 */ 
		final HorizontalPanel imagesHorizontalPanel = new HorizontalPanel();
		imagesHorizontalPanel.setSpacing(15);
			
		/*
		 * Images of the buttons for the functionality
		 */ 
		Image adminImage = new Image("img/admin.png");
		adminImage.setPixelSize(30, 30);
		adminImage.setAltText("Admin tools");
		adminImage.setStyleName("gwt-cursor");
		adminImage.setTitle("Admin tools");
		adminImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.assign("http://"+sHost+"/baasGUIAdminTools?session="+sSession+"&var="+Random.nextDouble()*51240.24+"&all="+iPrivileges*22.59);			
			}
		});
		
		Image alarmsImage = new Image("img/alarms.png");
		alarmsImage.setPixelSize(30, 30);
		alarmsImage.setAltText("Alarms tool");
		alarmsImage.setStyleName("gwt-cursor");
		alarmsImage.setTitle("Alarms tool");
		alarmsImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.assign("http://"+sHost+"/baasGUIAlarms?session="+sSession+"&var="+Random.nextDouble()*51240.24+"&all="+iPrivileges*21.87);			
			}
		});
		
		Image downloadImage = new Image("img/download.jpg");
		downloadImage.setPixelSize(30, 30);
		downloadImage.setAltText("Download data");
		downloadImage.setStyleName("gwt-cursor");
		downloadImage.setTitle("Download data");
		
		class DownloaderHandler implements ClickHandler {
			@Override
			public void onClick(ClickEvent event) {
				RootPanel.get("main").setVisible(false);
				//Pop-up to show the filters
				final PopupPanel popup = new PopupPanel();
				VerticalPanel vPanel = new VerticalPanel();
				vPanel.setSpacing(15);
				HorizontalPanel hPanel = new HorizontalPanel();
				hPanel.setSpacing(10);
				final DatePicker datePickerStart = new DatePicker();
				datePickerStart.setPixelSize(15, 15);
				final DatePicker datePickerEnd = new DatePicker();
				datePickerEnd.setPixelSize(15, 15);
				//Times to select the filters
				List<String> times = new ArrayList<String>();
				for(int i = 0; i < 24; i++){
					if(i < 10) times.add("0"+i+":00");
					else if(i >= 10) times.add(i+":00");
				}
				//List boxes for the times
				final ListBox listBoxTimesStart = new ListBox();
				listBoxTimesStart.setSelectedIndex(0);
				listBoxTimesStart.setMultipleSelect(false);
				final ListBox listBoxTimesEnd = new ListBox();
				listBoxTimesEnd.setSelectedIndex(0);
				listBoxTimesEnd.setMultipleSelect(false);
				for(String sTime : times){
					listBoxTimesStart.addItem(sTime);
					listBoxTimesEnd.addItem(sTime);
				}
				//Images to accept/decline the operation
				Image imgFilter = new Image("img/apply.png");
				imgFilter.setStyleName("gwt-cursor");
				imgFilter.setSize("20px", "20px");
				
				Image imgCancel = new Image("img/cancel.png");
				imgCancel.setStyleName("gwt-cursor");
				imgCancel.setSize("20px", "20px");
				
				final ListBox listBoxDevices = new ListBox();
				listBoxDevices.setSelectedIndex(0);
				listBoxDevices.setMultipleSelect(true);
				
				final ListBox listBoxBuildings = new ListBox();
				//List of buildings
				listBoxBuildings.addItem("");
				listBoxBuildings.addItem("CARTIF offices");
				listBoxBuildings.addItem("TUC offices");
				listBoxBuildings.addItem("ZUB offices");
				listBoxBuildings.addItem("Sierra Elvira School");
				listBoxBuildings.setMultipleSelect(false);
				listBoxBuildings.setSelectedIndex(0);
				vPanel.add(listBoxBuildings);
				
				if(hmCartifData.size() > 0 || hmZubData.size() > 0 ||
						hmTucData.size() > 0 || hmSierraData.size() > 0){
					
					Iterator<Entry<String, Map<String, String>>> it = hmCartifData.entrySet().iterator();
					while(it.hasNext()){
						//Get the sensors associate to each space
						Entry<String, Map<String, String>> entry = it.next();
						Map<String, String> asValues = entry.getValue();
						Object[] aDevices = asValues.keySet().toArray();
						//For each sensor, fill the list
						for(int i = 0; i < aDevices.length; i++){
							listBoxDevices.addItem(aDevices[i]+"-CARTIF");
						}
					}

					it = hmTucData.entrySet().iterator();
					while(it.hasNext()){
						//Get the sensors associate to each space
						Entry<String, Map<String, String>> entry = it.next();
						Map<String, String> asValues = entry.getValue();
						Object[] aDevices = asValues.keySet().toArray();
						//For each sensor, fill the list
						for(int i = 0; i < aDevices.length; i++){
							listBoxDevices.addItem(aDevices[i]+"-TUC");
						}
					}
					
					it = hmZubData.entrySet().iterator();
					while(it.hasNext()){
						//Get the sensors associate to each space
						Entry<String, Map<String, String>> entry = it.next();
						Map<String, String> asValues = entry.getValue();
						Object[] aDevices = asValues.keySet().toArray();
						//For each sensor, fill the list
						for(int i = 0; i < aDevices.length; i++){
							listBoxDevices.addItem(aDevices[i]+"-ZUB");
						}
					}
					
					it = hmSierraData.entrySet().iterator();
					while(it.hasNext()){
						//Get the sensors associate to each space
						Entry<String, Map<String, String>> entry = it.next();
						Map<String, String> asValues = entry.getValue();
						Object[] aDevices = asValues.keySet().toArray();
						//For each sensor, fill the list
						for(int i = 0; i < aDevices.length; i++){
							listBoxDevices.addItem(aDevices[i]+"-Sierra");
						}
					}
					
					if(listBoxDevices.getItemCount() == 0)
						listBoxDevices.addItem("No devices");
					
				}
				else
					listBoxDevices.addItem("No devices");
				
				vPanel.add(listBoxDevices);
				//Adding the times for the filters
				hPanel.add(new Label("Select date from "));
				hPanel.add(datePickerStart);
				hPanel.add(new Label(" "));
				hPanel.add(listBoxTimesStart);
				hPanel.add(new Label(" to "));
				hPanel.add(datePickerEnd);
				hPanel.add(new Label(" "));
				hPanel.add(listBoxTimesEnd);
				vPanel.add(hPanel);
				
				hPanel = new HorizontalPanel();
				hPanel.setSpacing(10);
				

				class CancelHandler implements ClickHandler {
					@Override
					public void onClick(ClickEvent event) {
						popup.hide();
						popup.clear();
						RootPanel.get("main").setVisible(true);
					}
				}
				
				class DownloadHandler implements ClickHandler{
					
					@Override
					public void onClick(ClickEvent event) {							
						String sDateIni = "";
						String sDateFin = "";
						if(datePickerStart.getValue() != null && datePickerEnd.getValue() != null){
							//Get the dates selected, list of devices and buildings associated
							sDateIni = datePickerStart.getValue().toString().substring(0, 11) + datePickerStart.getValue().toString().substring(28) + 
								" " + listBoxTimesStart.getItemText(listBoxTimesStart.getSelectedIndex());
							sDateFin = datePickerEnd.getValue().toString().substring(0, 11) + datePickerEnd.getValue().toString().substring(28) + 
								" " + listBoxTimesEnd.getItemText(listBoxTimesEnd.getSelectedIndex());
						}
						
						List<String> sSensors = new ArrayList<String>();
						for(int i = 0; i < listBoxDevices.getItemCount(); i++){
							if(listBoxDevices.isItemSelected(i))
								sSensors.add(listBoxDevices.getValue(i).substring(0, listBoxDevices.getValue(i).lastIndexOf("-")));
						}
						
						String sBuilding = "";
						//Depending on the building the ID is set
						if(listBoxBuildings.getItemText(listBoxBuildings.getSelectedIndex()).equals("CARTIF offices"))
							sBuilding = BuildingCodes.getsCartifBuildingCode();
						else if(listBoxBuildings.getItemText(listBoxBuildings.getSelectedIndex()).equals("TUC offices"))
							sBuilding = BuildingCodes.getsTucBuildingCode();
						else if(listBoxBuildings.getItemText(listBoxBuildings.getSelectedIndex()).equals("ZUB offices"))
							sBuilding = BuildingCodes.getsZubBuildingCode();
						else if(listBoxBuildings.getItemText(listBoxBuildings.getSelectedIndex()).equals("Sierra Elvira School"))
							sBuilding = BuildingCodes.getsSierraBuildingCode();
						
						if(!sDateIni.equals("") && !sDateFin.equals("") && sDateIni != null &&
								sDateFin != null && sSensors.size() > 0 && !sBuilding.equals("") &&
								sBuilding != null){
							popup.hide();
							popup.clear();
							
							final PopupPanel waitPanel = new PopupPanel();
							Image waitImg = new Image("img/wait.gif");
							waitImg.setSize("300px", "120px");
							waitPanel.add(waitImg);
							waitPanel.center();
							
							gwtService.downloadData(sDateIni, sDateFin, sSensors, sBuilding, new AsyncCallback<Map<String,Map<String,String>>>() {
								@Override
								public void onFailure(Throwable caught) {
									Window.alert(caught.getMessage());
									waitPanel.hide();
									RootPanel.get("main").setVisible(true);
								}

								@Override
								public void onSuccess(Map<String, Map<String, String>> result) {
									waitPanel.hide();
									
									//Generation of the file
									gwtService.createFile(result, new AsyncCallback<String>() {
										@Override
										public void onFailure(Throwable caught) {
											Window.alert(caught.getMessage());
											RootPanel.get("main").setVisible(true);										
										}

										@Override
										public void onSuccess(String result) {
											RootPanel.get("main").setVisible(true);	
											Window.open("sftp://"+Window.Location.getHostName()+"/"+result, "download_file", "Content-Type: application/CSV");											
										}
									});
								}
							});
						}
						else{
							popup.hide();
							Window.alert("All the filters must be selected");
							popup.center();
						}
					}
					
				}
				imgCancel.addClickHandler(new CancelHandler());
				imgFilter.addClickHandler(new DownloadHandler());
				
				hPanel.add(imgFilter);
				hPanel.add(imgCancel);
				vPanel.add(hPanel);
				popup.add(vPanel);
				popup.center();
			}
		}
		downloadImage.addClickHandler(new DownloaderHandler());

		Image homeImage = new Image("img/home.png");
		homeImage.setPixelSize(30, 30);
		homeImage.setAltText("Log out");
		homeImage.setStyleName("gwt-cursor");
		homeImage.setTitle("Log out");
		homeImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.assign("http://"+sHost+"/BaaSIndex");
				//Call the logout event
				gwtService.logout(sLogin, sSession, new AsyncCallback<Void>() {
					@Override
					public void onFailure(Throwable caught) {}

					@Override
					public void onSuccess(Void result) {}
				});
			}
		});
		
		Image kpiImage = new Image("img/kpi.jpg");
		kpiImage.setPixelSize(30, 30);
		kpiImage.setAltText("KPI and Optimization");
		kpiImage.setStyleName("gwt-cursor");
		kpiImage.setTitle("KPI and Optimization");
		kpiImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.assign("http://"+sHost+"/baasGUIOptimization?session="+sSession+"&var="+Random.nextDouble()*51240.24+"&all="+iPrivileges*18.61);			
			}
		});

		Image schedulersImage = new Image("img/schedulers.jpg");
		schedulersImage.setPixelSize(30, 30);
		schedulersImage.setAltText("Schedulers tool");
		schedulersImage.setStyleName("gwt-cursor");
		schedulersImage.setTitle("Schedulers tool");
		schedulersImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.assign("http://"+sHost+"/baasGUISchedulers?session="+sSession+"&var="+Random.nextDouble()*51240.24+"&all="+iPrivileges*16.16);			
			}
		});
		
		Image updateImage = new Image("img/update.png");
		updateImage.setPixelSize(30, 30);
		updateImage.setAltText("Update data");
		updateImage.setStyleName("gwt-cursor");
		updateImage.setTitle("Update data");
		updateImage.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.reload();
			}
		});
		
		/*
		 * TabLayoutPanel for the inclusion of the information about the building
		 */
		final TabLayoutPanel tabLayoutPanel = new TabLayoutPanel(30, Unit.PX);
		
		
		switch(iPrivileges){
			case 1:{
				imagesHorizontalPanel.clear();
				imagesHorizontalPanel.add(homeImage);
				imagesHorizontalPanel.add(updateImage);
				imagesHorizontalPanel.add(downloadImage);
				imagesHorizontalPanel.add(alarmsImage);
				imagesHorizontalPanel.add(adminImage);
				break;
			}
			case 2:{		
				imagesHorizontalPanel.clear();
				imagesHorizontalPanel.add(homeImage);
				imagesHorizontalPanel.add(updateImage);
				imagesHorizontalPanel.add(downloadImage);
				imagesHorizontalPanel.add(kpiImage);
				imagesHorizontalPanel.add(schedulersImage);
				imagesHorizontalPanel.add(alarmsImage);
				break;
			}
			case 3:{
				imagesHorizontalPanel.clear();
				imagesHorizontalPanel.add(homeImage);
				imagesHorizontalPanel.add(updateImage);
				break;
			}
		}
		//Include the buttons into the mainVerticalPanel
		mainVerticalPanel.add(imagesHorizontalPanel);		
		
		/*
		 * For each building it is displayed a tab with the corresponding measurements
		 */
		for(String sBuilding : lsBuildings){
		if(sBuilding.equals(BuildingCodes.getsTucBuildingCode())){	
			tabLayoutPanel.add(printScreen.printScreen(hmTucData, hmMonthTucData, "TUC"), "TUC offices", true);
		}
		else if(sBuilding.equals(BuildingCodes.getsCartifBuildingCode())){
//			tabLayoutPanel.add(new Label(), "CARTIF offices", true);
			tabLayoutPanel.add(printScreen.printScreen(hmCartifData, hmMonthCartifData, "CARTIF"), "CARTIF offices", true);
		}
		else if(sBuilding.equals(BuildingCodes.getsZubBuildingCode())){
//			tabLayoutPanel.add(new Label(), "ZUB offices", true);
			tabLayoutPanel.add(printScreen.printScreen(hmZubData, hmMonthZubData, "ZUB"), "ZUB offices", true);
		}
		/*else if(sBuilding.equals(BuildingCodes.getsHusaBuildingCode())){
			tabLayoutPanel.add(printScreen.printScreen(hmHusaData, hmMonthHusaData, "HUSA"), "Husa hotel", true);
		}*/
		else if(sBuilding.equals(BuildingCodes.getsSierraBuildingCode())){
//			tabLayoutPanel.add(new Label(), "Sierra Elvira School", true);
			tabLayoutPanel.add(printScreen.printScreen(hmSierraData, hmMonthSierraData, "SIERRA"), "Sierra Elvira School", true);
		}
	}		
		
//		ScrollPanel scrollContent = printScreen.printScreen(hmTucData, hmMonthTucData, "TUC");
//
//		tabLayoutPanel.add(scrollContent, "TUC offices", true);
//		tabLayoutPanel.add(new Label(), "CARTIF offices", true);	
//		tabLayoutPanel.add(new Label(), "ZUB offices", true);
//		tabLayoutPanel.add(new Label(), "Sierra Elvira School", true);
//		tabLayoutPanel.selectTab(0);
//			
//		//Handler in case of selection
//		tabLayoutPanel.addSelectionHandler(new SelectionHandler<Integer>() {
//			@Override
//			public void onSelection(SelectionEvent<Integer> event) {		
//				//TUC building
//				if (event.getSelectedItem() == 0) {
//			        Scheduler.get().scheduleDeferred(new ScheduledCommand() {
//						@Override
//						public void execute() {
//							tabLayoutPanel.remove(0);
//							tabLayoutPanel.insert(printScreen.printScreen(hmTucData, hmMonthTucData, "TUC"), "TUC offices", 0);
//							tabLayoutPanel.selectTab(0);
//						}
//					}); 
//			    }
//				//CARTIF building
//				else if (event.getSelectedItem() == 1) {
//			        Scheduler.get().scheduleDeferred(new ScheduledCommand() {
//						@Override
//						public void execute() {
//							tabLayoutPanel.remove(1);
//							tabLayoutPanel.insert(printScreen.printScreen(hmCartifData, hmMonthCartifData, "CARTIF"), "CARTIF offices", 1);
//							tabLayoutPanel.selectTab(1);
//						}
//					}); 
//			    }
//				//ZUB building
//				else if (event.getSelectedItem() == 2) {
//			        Scheduler.get().scheduleDeferred(new ScheduledCommand() {
//						@Override
//						public void execute() {
//							tabLayoutPanel.remove(2);
//							tabLayoutPanel.insert(printScreen.printScreen(hmZubData, hmMonthZubData, "ZUB"), "ZUB offices", 2);
//							tabLayoutPanel.selectTab(2);
//						}
//					}); 
//			    }
//				//Sierra Elvira building
//				else if (event.getSelectedItem() == 3) {
//			        Scheduler.get().scheduleDeferred(new ScheduledCommand() {
//						@Override
//						public void execute() {
//							tabLayoutPanel.remove(3);
//							tabLayoutPanel.insert(printScreen.printScreen(hmSierraData, hmMonthSierraData, "SIERRA"), "Sierra Elvira School", 3);
//							tabLayoutPanel.selectTab(3);
//						}
//					}); 
//			    }
//			}
//		});
		
		
		tabLayoutPanel.setPixelSize(1150, 600);
		mainVerticalPanel.add(tabLayoutPanel);
		
		rootLayout.add(mainVerticalPanel);
		RootPanel.get("main").add(rootLayout);
		
	}
}
