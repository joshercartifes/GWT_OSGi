package com.cartif.gui.monitoring.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.googlecode.gwt.charts.client.ColumnType;
import com.googlecode.gwt.charts.client.DataTable;
import com.googlecode.gwt.charts.client.ChartLoader;
import com.googlecode.gwt.charts.client.ChartPackage;
import com.googlecode.gwt.charts.client.corechart.LineChart;
import com.googlecode.gwt.charts.client.corechart.LineChartOptions;
import com.googlecode.gwt.charts.client.options.AxisTitlesPosition;
import com.googlecode.gwt.charts.client.options.ChartArea;

public class Graphs{
	HorizontalPanel atlHorizontalPanel = null;
	
	public Graphs(){}
	
	public Graphs(Map<String, Map<String, Map<String, String>>> hmMonthData, String sSelectedZone){
		atlHorizontalPanel = new HorizontalPanel();
		atlHorizontalPanel = printGraph(hmMonthData, sSelectedZone);
	}
	
	public HorizontalPanel getAtlHorizontalPanel() {
		return atlHorizontalPanel;
	}

	public void setAtlHorizontalPanel(HorizontalPanel atlHorizontalPanel) {
		this.atlHorizontalPanel = atlHorizontalPanel;
	}

	/**
	 * Method that prints the graphs and trends in the screen with the data associated to
	 * the zone. Thus, when the stack panel changes in the selected zone, it is called this
	 * method to update the graphs
	 * 
	 * @param sSelectedZone Zone selected of the stack panel
	 * @param hmMonthData Data from the latest month associated to the building
	 * @param rightVerticalPanel 
	 * @return Horizontal Panel with the trend
	 */
	public HorizontalPanel printGraph(Map<String, Map<String, Map<String, String>>> hmMonthData, String sSelectedZone){
		atlHorizontalPanel.setSpacing(15);
		atlHorizontalPanel.setBorderWidth(0);
		
		if(sSelectedZone != null){
			//If the data is not collected, no graph should be displayed
			if(hmMonthData.size() > 0){
			
				//Get the list of values of the sensors in the Zone visible in the stack panel
				final Map<String, Map<String,String>> hmSensorsByZone = hmMonthData.get(sSelectedZone);

				//Get the list of sensors associated to the Zone selected
				Object[] asSensors = hmSensorsByZone.keySet().toArray();
			
		
				//Only if the length of sensors is upper than 0
				if(asSensors.length > 0){
			
					final List<String> lsSensors = new ArrayList<String>();
				
					for(int i = 0; i < asSensors.length; i++){
						lsSensors.add(asSensors[i].toString());
					}

					//Creating the chart
					ChartLoader chartLoader = new ChartLoader(ChartPackage.CORECHART);
				
					chartLoader.loadApi(new Runnable() {
						@Override
						public void run() {

							// call method to create and show the chart
							DataTable dataTable = DataTable.create();
						
							//Columnas a mostrar, la primera para el eje de abscisas (fecha) y la segunda para
							//los valores en el eje de ordenadas
							dataTable.addColumn(ColumnType.DATE, "Date");

							for(String sSensor : lsSensors){
								dataTable.addColumn(ColumnType.NUMBER, sSensor);
							}
													
							DateTimeFormat dtf = DateTimeFormat.getFormat("yyyy-MM-dd hh:mm:ss.SSS");
										
							//Se a�aden los valores y los puntos para dibujar la gr�fica
							for(int j = 0; j < lsSensors.size(); j++){
								//Delete all the rows related to the sensor j
							
								Map<String,String> hmValues = hmSensorsByZone.get(lsSensors.get(j));
													
								//Only if the size of the values is upper than 0
								if(hmValues.size() > 0){
													
									Object[] asTimestamps = (Object[]) hmValues.keySet().toArray();	
									Object[] asValues = (Object[]) hmValues.values().toArray();	
										
									if(dataTable.getNumberOfRows() < asTimestamps.length)
										dataTable.addRows(asTimestamps.length - dataTable.getNumberOfRows());
								
									for(int i = 0; i < asTimestamps.length; i++){
										String sTimestamp = asTimestamps[i].toString();
										String sValue = asValues[i].toString();
										Double dValue = Double.valueOf(sValue);

										dataTable.setValue(i+1, 0, dtf.parse(sTimestamp)); 
										dataTable.setValue(i+1, j+1, dValue);
									}						
																
								}
							}
							LineChartOptions options = LineChartOptions.create();
							options.setAxisTitlesPosition(AxisTitlesPosition.IN);
							ChartArea chartArea = ChartArea.create(); 
							chartArea.setWidth(1000);
							chartArea.setHeight(800);
							options.setChartArea(chartArea);
						
							LineChart lineChart = new LineChart();
							lineChart.draw(dataTable, options);

							atlHorizontalPanel.add(lineChart);
							
						}
					});
				}	
			}
			else{
				//Creating the chart
				ChartLoader chartLoader = new ChartLoader(ChartPackage.CORECHART);
				chartLoader.loadApi(new Runnable() {
					@Override
					public void run() {
						// call method to create and show the chart
						DataTable data = DataTable.create();
						data.addColumn(ColumnType.DATE, "Date");
						data.addColumn(ColumnType.NUMBER, "Value");
						data.addRows(1);
						DateTimeFormat dtf = DateTimeFormat.getFormat("yyyy.MM.dd hh:mm");
						data.setValue(0, 0,	dtf.parse("2014.01.01 00:00")); 
					
						LineChartOptions options = LineChartOptions.create();
						options.setAxisTitlesPosition(AxisTitlesPosition.IN);
						ChartArea chartArea = ChartArea.create(); 
						chartArea.setWidth(750);
						chartArea.setHeight(550);
						options.setChartArea(chartArea);
					
						LineChart lineChart = new LineChart();
						lineChart.draw(data, options);
					
						atlHorizontalPanel.add(lineChart);
					
					}
				});
			}
		}
		else{
			//Creating the chart
			ChartLoader chartLoader = new ChartLoader(ChartPackage.CORECHART);
			chartLoader.loadApi(new Runnable() {
				@Override
				public void run() {
					// call method to create and show the chart
					DataTable data = DataTable.create();
					data.addColumn(ColumnType.DATE, "Date");
					data.addColumn(ColumnType.NUMBER, "Value");
					data.addRows(1);
					DateTimeFormat dtf = DateTimeFormat.getFormat("yyyy.MM.dd hh:mm");
					data.setValue(0, 0,	dtf.parse("2014.01.01 00:00")); 
				
					LineChartOptions options = LineChartOptions.create();
					options.setAxisTitlesPosition(AxisTitlesPosition.IN);
					ChartArea chartArea = ChartArea.create(); 
					chartArea.setWidth(550);
					chartArea.setHeight(450);
					options.setChartArea(chartArea);
				
					LineChart lineChart = new LineChart();
					lineChart.draw(data, options);
				
					atlHorizontalPanel.add(lineChart);
				
				}
			});
		}
	
		return atlHorizontalPanel;
	}
}
