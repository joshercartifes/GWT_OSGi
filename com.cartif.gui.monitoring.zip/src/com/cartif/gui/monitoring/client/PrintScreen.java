package com.cartif.gui.monitoring.client;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.StackLayoutPanel;
import com.google.gwt.user.client.ui.VerticalPanel;


public class PrintScreen {

	/**
	 * Method that prints the information regarding the latest readings stored in the DWH. First
	 * of all, the information is unrolled for displaying a set of tables with the information
	 * which are added into the StackPanel with one row for each zone in the building.
	 * 
	 * @param hmData Map with the data read from the DWH
	 * @param hmMonthTucData 
	 * @return
	 */
	public ScrollPanel printScreen(final Map<String,Map<String,String>> hmData, final Map<String, Map<String, Map<String, String>>> hmMonthData, final String sBuildingName){
		/*
		 * HorizontalPanel to be divided in two parts (left side for the values,
		 * right side for the trend)
		 */
		HorizontalPanel horizontalPanel = new HorizontalPanel();
		horizontalPanel.setSpacing(15);
		horizontalPanel.setBorderWidth(0);
		/*
		 * Internal Horizontal y Vertical panel for creating the tables where the 
		 * measurements are displayed
		 */
		HorizontalPanel internalHorizontalPanel = new HorizontalPanel();
		VerticalPanel internalVerticalPanel = new VerticalPanel();

		
		/*
		 * StackLayoutPanel for the values obtained from the DWH in function of the zones,
		 * sensors associated and their values with Timestamp
		 */
		final StackLayoutPanel stackLayoutPanel = new StackLayoutPanel(Unit.PX);
		
//		if(sBuildingName.equalsIgnoreCase("TUC")){
//			stackLayoutPanel.setPixelSize(500, 1400);
//		}
//		else if(sBuildingName.equalsIgnoreCase("CARTIF")){
//			stackLayoutPanel.setPixelSize(500, 3750);
//		}
//		else if(sBuildingName.equalsIgnoreCase("ZUB")){
//			stackLayoutPanel.setPixelSize(500, 1200);
//		}
//		else if(sBuildingName.equalsIgnoreCase("Sierra")){
//			stackLayoutPanel.setPixelSize(500, 4150);
//		}
		stackLayoutPanel.setWidth(500 + "px");
		
				
		//Iterator of the HashMap
		Iterator<Entry<String,Map<String,String>>> mainIterator = hmData.entrySet().iterator();
		
		if(hmData.size() == 0){
			Image noDataImage = new Image("img/NoData.png");
			noDataImage.setPixelSize(250, 120);
			stackLayoutPanel.add(noDataImage,"No data available",30);
		}
		
		else{
			int iItems = 0;
			
			//While information is available, the measurements are printed out
			while(mainIterator.hasNext()){
				Entry<String,Map<String,String>> mainEntry = mainIterator.next();
				//Get the zone which is the key of the map
				String sZone = mainEntry.getKey();
				
				if(sBuildingName.equals("SIERRA"))
					iItems += 22;
				else if(sBuildingName.equals("ZUB"))
					iItems += 10;
				else if(sBuildingName.equals("CARTIF"))
					iItems += 9;
				else if(sBuildingName.equals("TUC"))
					iItems += 8;
							
				internalHorizontalPanel = new HorizontalPanel();
				internalHorizontalPanel.setBorderWidth(1);
				internalHorizontalPanel.setSpacing(10);
				
				internalVerticalPanel = new VerticalPanel();
				internalVerticalPanel.setBorderWidth(0);
				internalVerticalPanel.setSpacing(5);	
				internalVerticalPanel.setPixelSize(500, 100);
				
//				internalVerticalPanel.add(new HTML(SafeHtmlUtils.fromString(sZone)));
				
				/*
				 * The headers of the table to be shown are inserted in a label
				 */
				Label label = new Label("Sensor");
				label.setPixelSize(200, 20);
				internalHorizontalPanel.add(label);
				
				label = new Label("Timestamp");
				label.setPixelSize(180, 20);
				internalHorizontalPanel.add(label);
				
				label = new Label("Value");
				label.setPixelSize(60, 20);
				internalHorizontalPanel.add(label);
				internalVerticalPanel.add(internalHorizontalPanel);
				
				
			
				//Second Map with the values, timestamps and so on.
				Map<String,String> hmSecondMap = mainEntry.getValue();
				//Iterator of the second HashMap
				Iterator<Entry<String,String>> secondIterator = hmSecondMap.entrySet().iterator();
			
				//Whereas the internal map has information, then it is gathered
				if(hmSecondMap.size() > 0){
					while(secondIterator.hasNext()){
						if(sBuildingName.equals("SIERRA"))
							iItems += 22;
						else if(sBuildingName.equals("ZUB"))
							iItems += 10;
						else if(sBuildingName.equals("CARTIF"))
							iItems += 9;
						else if(sBuildingName.equals("TUC"))
							iItems += 8;
						
						internalHorizontalPanel = new HorizontalPanel();
//						internalHorizontalPanel.setBorderWidth(1);
						internalHorizontalPanel.setSpacing(10);
				
						Entry<String,String> secondEntry = secondIterator.next();
						//Get the information of the sensor name and the values with Timestamp
						String sSensor = secondEntry.getKey();
						String sMeasurement = secondEntry.getValue();
						//StringTokenizer for dividing the timestamp and value 
						String[] sMeasurements = sMeasurement.split(";");
				
						String sTimestamp = sMeasurements[0]; 
						String sValue = sMeasurements[1];
						
						String sSensor2 = "";
								
						
						if(sSensor.contains("_")){
							String[] asSensor = sSensor.split("_");
							for(int i = 0; i < asSensor.length; i++){
								if(i == 0)
									sSensor2 = asSensor[i] + " ";
								else
									sSensor2 = sSensor2 + asSensor[i] + " ";
							}
						}
						
//						else if(sSensor.contains(".")){
//							String[] asSensor = sSensor.split(".");
//							for(int i = 0; i < asSensor.length; i++){
//								if(i == 0)
//									sSensor2 = asSensor[i] + " ";
//								else
//									sSensor2 = sSensor2 + asSensor[i] + " ";
//							}
//						}
						else
							sSensor2 = sSensor;
											
						//Inserting the information of the readings
						label = new Label(sSensor2);
						label.setPixelSize(200, 20);
						internalHorizontalPanel.add(label);
				
						label = new Label(sTimestamp);
						label.setPixelSize(180, 20);
						internalHorizontalPanel.add(label);
				
						label = new Label(sValue);
						label.setPixelSize(60, 20);
						internalHorizontalPanel.add(label);
						internalVerticalPanel.add(internalHorizontalPanel);
					}
				}
				else{
					if(sBuildingName.equals("SIERRA"))
						iItems += 22;
					else if(sBuildingName.equals("ZUB"))
						iItems += 10;
					else if(sBuildingName.equals("CARTIF"))
						iItems += 9;
					else if(sBuildingName.equals("TUC"))
						iItems += 8;
					
					internalHorizontalPanel = new HorizontalPanel();
					internalHorizontalPanel.setSpacing(10);
					
					label = new Label("No data");
					label.setPixelSize(200, 20);
					internalHorizontalPanel.add(label);
				
					label = new Label("No data");
					label.setPixelSize(180, 20);
					internalHorizontalPanel.add(label);
					
					label = new Label("No data");
					label.setPixelSize(60, 20);
					internalHorizontalPanel.add(label);
					internalVerticalPanel.add(internalHorizontalPanel);
				}
				//Fill the stack panel
				stackLayoutPanel.add(internalVerticalPanel, sZone, 30);	
			}		
			
//			int iStackSize = iItems * 15;
//			stackLayoutPanel.setHeight(iStackSize + "px");
			stackLayoutPanel.setHeight(iItems + "px");
		}
		
		
		/*
		 * Now the right part of the screen is built with the pictures of the building and the
		 * trend of the variables.
		 */
		Image cartif1Image = new Image("img/cartif1.jpg");
		cartif1Image.setPixelSize(230, 195);
		Image cartif2Image = new Image("img/cartif2.png");
		cartif2Image.setPixelSize(230, 195);
		Image tuc1Image = new Image("img/TUC1.jpg");
		tuc1Image.setPixelSize(230, 195);
		Image tuc2Image = new Image("img/TUC2.jpg");
		tuc2Image.setPixelSize(230, 195);
//		Image husa1Image = new Image("img/husa1.jpg");
//		husa1Image.setPixelSize(230, 195);
//		Image husa2Image = new Image("img/husa2.jpg");
//		husa2Image.setPixelSize(230, 195);
		Image zub1Image = new Image("img/Zub1.jpg");
		zub1Image.setPixelSize(230, 195);
		Image zub2Image = new Image("img/Zub2.jpg");
		zub2Image.setPixelSize(230, 195);
		Image sierra1Image = new Image("img/Sierra1.png");
		sierra1Image.setPixelSize(230, 195);
		Image sierra2Image = new Image("img/Sierra2.jpg");
		sierra2Image.setPixelSize(230, 195);
		
		/*
		 * Horizontal and Vertical Panel for the right part of the panel 
		 */
		final HorizontalPanel rightHorizontalPanel = new HorizontalPanel();
		rightHorizontalPanel.setSpacing(15);
		rightHorizontalPanel.setBorderWidth(0);
		final VerticalPanel rightVerticalPanel = new VerticalPanel();
		rightVerticalPanel.setSpacing(10);
		rightVerticalPanel.setBorderWidth(0);
		
		//Including the pictures of the buildings
		if(sBuildingName.equals("TUC")){
			rightHorizontalPanel.add(tuc1Image);
			rightHorizontalPanel.add(tuc2Image);
		}
		else if(sBuildingName.equals("CARTIF")){
			rightHorizontalPanel.add(cartif1Image);
			rightHorizontalPanel.add(cartif2Image);
		}
		else if(sBuildingName.equals("ZUB")){
			rightHorizontalPanel.add(zub1Image);
			rightHorizontalPanel.add(zub2Image);
		}
//		else if(sBuildingName.equalsIgnoreCase("husa")){
//			rightHorizontalPanel.add(husa1Image);
//			rightHorizontalPanel.add(husa2Image);
//		}
		else if(sBuildingName.equals("SIERRA")){
			rightHorizontalPanel.add(sierra1Image);
			rightHorizontalPanel.add(sierra2Image);
		}
		rightVerticalPanel.add(rightHorizontalPanel);
		
		/**
		 * Selection handler to manage the events assigned to the stack panel
		 * 
		 * @author Cartif
		 *
		 */
		class SelectorHandler implements SelectionHandler<Integer>{
			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				rightVerticalPanel.clear();
				rightVerticalPanel.add(rightHorizontalPanel);
				int iStackIndex = stackLayoutPanel.getVisibleIndex();
				Object[] asSensors = hmMonthData.keySet().toArray();
				String sSelectedZone = asSensors[iStackIndex].toString();
				Graphs graph = new Graphs(hmMonthData, sSelectedZone);
				rightVerticalPanel.add(graph.getAtlHorizontalPanel());
			}
		}
//		stackLayoutPanel.addSelectionHandler(new SelectorHandler());
//		
		horizontalPanel.add(stackLayoutPanel);
		
		int iStackIndex = stackLayoutPanel.getVisibleIndex();
		Object[] asSensors = hmMonthData.keySet().toArray();

		if(asSensors.length > 0){
			String sSelectedSpace = asSensors[iStackIndex].toString();
			Graphs graph = new Graphs(hmMonthData, sSelectedSpace);
			rightVerticalPanel.add(graph.getAtlHorizontalPanel());
		}
		
		else{
			Graphs graph2 = new Graphs(hmMonthData, null);
			rightVerticalPanel.add(graph2.getAtlHorizontalPanel());
		}
		

		horizontalPanel.add(rightVerticalPanel);
		/**
		 * Scroll Panel to add scrolling to the system
		 */
		ScrollPanel scrollPanel = new ScrollPanel();
		scrollPanel.add(horizontalPanel);
		return scrollPanel;
	}
	
	
}
