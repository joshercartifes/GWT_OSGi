package com.cartif.gui.monitoring.server;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cartif.gui.monitoring.client.AppService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
public class AppServiceImpl extends RemoteServiceServlet implements AppService {
	private static final long serialVersionUID = 1L;
	
	/**
	 * Variables for the session and user, so as to check if session is created
	 */
	private static Map<String,String> hmUser = new HashMap<String, String>();

	@Override
	public Map<String, String> getHmUser() {
		return hmUser;
	}
	
	public static Map<String, String> getHmUser(boolean bFlag) {
		return hmUser;
	}

	public static void setHmUser(Map<String, String> hmUser) {
		AppServiceImpl.hmUser = hmUser;
	}

	/**
	 * Method which overrides the service from the HttpSerlvet objects
	 */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Thread currentThread = Thread.currentThread();
	    ClassLoader oldContextClassLoader = currentThread.getContextClassLoader();
	    currentThread.setContextClassLoader(this.getClass().getClassLoader());
	    super.service(req, resp);
	    currentThread.setContextClassLoader(oldContextClassLoader);
	}
	
	/**
	 * Method received in the server side to perform the check
	 */
	@Override
	public Map<String,Map<String, Map<String, String>>> getData(List<String> lsBuildingCodes) throws Exception {
		Monitoring_Handler.getData(lsBuildingCodes);
		/*
		 * Meanwhile the data requested associates to the building is not filled, the return
		 * code part is not executed
		 */
		while(Monitoring_Handler.hmCartifData == null || Monitoring_Handler.hmTucData == null ||
				Monitoring_Handler.hmZubData == null || Monitoring_Handler.hmSierraData == null){
			//do nothing until fill the Map of data
			Thread.sleep(100);
		}
		
		//Fill the return object
		Map<String,Map<String, Map<String, String>>> data = new HashMap<String, Map<String,Map<String,String>>>();
		data.put("TUC", Monitoring_Handler.hmTucData);
		data.put("CARTIF", Monitoring_Handler.hmCartifData);
		data.put("ZUB", Monitoring_Handler.hmZubData);
		data.put("SIERRA", Monitoring_Handler.hmSierraData);
		
		Monitoring_Handler.hmTucData = null;
		Monitoring_Handler.hmCartifData = null;
		Monitoring_Handler.hmZubData = null;
		Monitoring_Handler.hmSierraData = null;
		
		return data;
	}

	/**
	 * Method for the server side in order to retrieve the monthly information associated to 
	 * the zones and sensors.
	 */
	@Override
	public Map<String,Map<String, Map<String, Map<String, String>>>> getMonthlyData(List<String> lsBuildingCodes) throws Exception {
		Monitoring_Handler.getMonthlyData(lsBuildingCodes);
		/*
		 * Meanwhile the data requested associates to the building is not filled, the return
		 * code part is not executed
		 */
		while(Monitoring_Handler.hmMonthCartifData == null || Monitoring_Handler.hmMonthTucData == null ||
				Monitoring_Handler.hmMonthZubData == null || Monitoring_Handler.hmMonthSierraData == null){
			//do nothing until fill the Map of data
			Thread.sleep(100);
		}
		
		//Fill the return object
		Map<String,Map<String, Map<String, Map<String, String>>>> data = new HashMap<String,Map<String, Map<String, Map<String, String>>>>();
		data.put("TUC", Monitoring_Handler.hmMonthTucData);
		data.put("CARTIF", Monitoring_Handler.hmMonthCartifData);
		data.put("ZUB", Monitoring_Handler.hmMonthZubData);
		data.put("SIERRA", Monitoring_Handler.hmMonthSierraData);
				
		Monitoring_Handler.hmMonthCartifData = null;
		Monitoring_Handler.hmMonthTucData = null;
		Monitoring_Handler.hmMonthZubData = null;
		Monitoring_Handler.hmMonthSierraData = null;
		
		return data;
	}

	/**
	 * Server side where the downloading of the information is done by sending the
	 * event to the DWH Connector
	 * @return 
	 * @throws Exception 
	 */
	@Override
	public Map<String, Map<String, String>> downloadData(String sDateIni, String sDateFin, List<String> lsSensors, String sBuildingCode) throws Exception {
		Monitoring_Handler.downloadData(sDateIni, sDateFin, lsSensors, sBuildingCode);
		while(Monitoring_Handler.hmDownloadedData == null){
			//do nothing until fill the Map of data
			Thread.sleep(100);
		}
		
		return Monitoring_Handler.hmDownloadedData;
	}

	/**
	 * Method for the creation of the file in the FileGenerator. It returns the string with
	 * the file name
	 */
	@Override
	public String createFile(Map<String, Map<String, String>> hmData) {
		FileGenerator fileGen = new FileGenerator();
		return fileGen.generateFile(hmData);
	}
	
	/**
	 * Method that launches the logout event
	 */
	@Override
	public void logout(String sLogin, String sSession){
		Monitoring_Handler.logout(sLogin, sSession);
	}
}
