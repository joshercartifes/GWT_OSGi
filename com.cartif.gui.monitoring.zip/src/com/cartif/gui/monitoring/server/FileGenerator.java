package com.cartif.gui.monitoring.server;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Class for the generation of the file from the downloaded data
 * @author Cartif
 *
 */
public class FileGenerator {
	
	/**
	 * Method that generates the file from the data downloaded
	 * 
	 */
	public String generateFile (Map<String, Map<String, String>> hmData){
		try {
			File file = new File(System.getProperty("user.dir")+"/data.csv");
			file.setWritable(true);
		
			FileWriter writer = new FileWriter(file);
				
			//Get all the sensors of the data map
			Object[] asSensors = hmData.keySet().toArray();
		
			writer.write("Sensor");
			writer.write(";");
			writer.write("Timestamp");
			writer.write(";");
			writer.write("Value");
			writer.write("\n");
			
			/*
			 * For each sensor, it is got the timestamp and value and it is added a new row
			 */
			for(int i = 0; i < asSensors.length; i++){
				Map<String, String> hmInfo = hmData.get(asSensors[i].toString());
				Iterator<Entry<String,String>> iterator = hmInfo.entrySet().iterator();
				/*
				 * While data is collected for the sensor, the csv is written
				 */
				while(iterator.hasNext()){
					Entry<String, String> entry = iterator.next();
					if(entry.getKey().startsWith("20")){
						writer.write(asSensors[i].toString());
						writer.write(";");
						writer.write(entry.getKey());
						writer.write(";");
						writer.write(entry.getValue());
						writer.write("\n");
					}
				}
			}
			writer.close();
			return file.getName();
		
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}
}
