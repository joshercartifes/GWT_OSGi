package com.cartif.gui.monitoring.server;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.service.event.EventHandler;

import com.cartif.gui.monitoring.shared.BuildingCodes;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Monitoring_Handler implements EventHandler {
	private static EventAdmin eventAdmin;
	static Map<String, Object> props = new HashMap<String, Object>();
	static Map<String,Map<String,String>> hmTucData = null;
	static Map<String,Map<String,String>> hmCartifData = null;
	static Map<String,Map<String,String>> hmZubData = null;
	static Map<String,Map<String,String>> hmHusaData = null;
	static Map<String,Map<String,String>> hmSierraData = null;
	
	static Map<String,Map<String,Map<String,String>>> hmMonthTucData = null;
	static Map<String,Map<String,Map<String,String>>> hmMonthCartifData = null;
	static Map<String,Map<String,Map<String,String>>> hmMonthZubData = null;
	static Map<String,Map<String,Map<String,String>>> hmMonthHusaData = null;
	static Map<String,Map<String,Map<String,String>>> hmMonthSierraData= null;
	
	static Map<String,Map<String,String>> hmDownloadedData = null;
	
	/** 
	 * Constructor
	 */
	public Monitoring_Handler() { 
	}
		
	public EventAdmin getEventAdmin() {
		return eventAdmin;
	}

	public void setEventAdmin(EventAdmin eventAdmin) {
		
		System.out.println("/////////////////////////////////////////////");
		System.out.println("EVENT ADMIN INJECTED in monitoring "+eventAdmin);
		System.out.println("/////////////////////////////////////////////");
		Monitoring_Handler.eventAdmin = eventAdmin;

	}	
	
	/**
	 * This method is executed when a topic is received
	 * @param event The event received
	 */
	@SuppressWarnings("unchecked")
	public void handleEvent(Event event){
		
		System.out.println("/////////////////////////////////////////////");
		System.out.println("EVENT RECEIVED with topic: " + event.getTopic());
		System.out.println("/////////////////////////////////////////////");
		
		/**
		 * Management of the event received about the latest data from the DWH
		 */
		if(event.getTopic().equalsIgnoreCase("org/baas/guiConnector/trigger/guiDataResponse")){
			event.getProperty("processId");
			String sBuilding = (String)event.getProperty("buildingID");
			Map<String,Map<String,String>> hmData = (Map<String,Map<String,String>>)event.getProperty("data");
			
			if(sBuilding.equals(BuildingCodes.getsCartifBuildingCode()))
				hmCartifData = new HashMap<String, Map<String,String>>(hmData); 
			
			else if(sBuilding.equals(BuildingCodes.getsTucBuildingCode()))
				hmTucData = new HashMap<String, Map<String,String>>(hmData); 

			else if(sBuilding.equals(BuildingCodes.getsZubBuildingCode()))
				hmZubData = new HashMap<String, Map<String,String>>(hmData); 

			else if(sBuilding.equals(BuildingCodes.getsSierraBuildingCode()))
				hmSierraData = new HashMap<String, Map<String,String>>(hmData); 

			/*else if(sBuilding.equals(BuildingCodes.getsHusaBuildingCode()))
				hmHusaData.putAll(hmData);*/
		}
		
		/**
		 * Management of the event received about the monthly data from the DWH
		 */
		else if(event.getTopic().equalsIgnoreCase("org/baas/guiConnector/trigger/guiMonthDataResponse")){
			
			event.getProperty("processId");
			String sBuilding = (String)event.getProperty("buildingID");
			Map<String,Map<String,Map<String,String>>> hmData = (Map<String,Map<String,Map<String,String>>>)event.getProperty("data");
			
//			System.out.println("**********************************************************************");
//			System.out.println("\tBuilding: "+sBuilding);
//			
			
			if(sBuilding.equals(BuildingCodes.getsCartifBuildingCode()))
				hmMonthCartifData = new HashMap<String, Map<String,Map<String,String>>>(hmData);
			else if(sBuilding.equals(BuildingCodes.getsTucBuildingCode()))
				hmMonthTucData = new HashMap<String, Map<String,Map<String,String>>>(hmData);
			else if(sBuilding.equals(BuildingCodes.getsZubBuildingCode())){
//				System.out.println("\tZUB data: "+hmData);
				hmMonthZubData = new HashMap<String, Map<String,Map<String,String>>>(hmData);
			}
			else if(sBuilding.equals(BuildingCodes.getsSierraBuildingCode()))
				hmMonthSierraData = new HashMap<String, Map<String,Map<String,String>>>(hmData);
			/*else if(sBuilding.equals(BuildingCodes.getsHusaBuildingCode()))
				hmMonthHusaData.putAll(hmData);*/
			
//			System.out.println("**********************************************************************");
		}
		
		/**
		 * Management of the event received about the downloaded data
		 */
		else if(event.getTopic().equalsIgnoreCase("org/baas/guiConnector/trigger/guiDownDataResponse")){
			event.getProperty("processId");
			hmDownloadedData = new HashMap<String, Map<String,String>>((Map<String, Map<String, String>>)event.getProperty("data"));
		}
		
	}
	
	/**
	 * Method that sends the event to the DWH Connector in order to retrieve the latest
	 * data to be shown in the GUI.
	 * 
	 * @param sBuildingCode Building identifier where the data are taken
	 */
	public static void getData(List<String> lsBuildingCodes){
		for(String sBuildingCode : lsBuildingCodes){
			props.clear();
			props.put("processId", "guiConnector");
			props.put("buildingId", sBuildingCode);
			eventAdmin.postEvent(new Event("org/baas/dwhConnector/trigger/retrieveGUIData", props));
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
		}
	}
	
	/**
	 * Method that sends the event to the DWH Connector in order to get the data associated to
	 * the latest month.
	 * 
	 * @param sBuildingCode Building identifier where the data are taken
	 */
	public static void getMonthlyData(List<String> lsBuildingCodes){
		for(String sBuildingCode : lsBuildingCodes){
			props.clear();
			props.put("processId", "guiConnector");
			props.put("buildingId", sBuildingCode);
			eventAdmin.postEvent(new Event("org/baas/dwhConnector/trigger/retrieveMonthGUIData", props));
			
//			System.out.println("\t------------------------------------------------------------------------");
//			System.out.println("\t\tEvent sent with building ID: "+sBuildingCode);
//			System.out.println("\t------------------------------------------------------------------------");

		}
	}
	
	/**
	 * Method that sends the event for downloading the data selected in the filters of the
	 * Graphical User Interface.
	 * 
	 * @param sDateIni Initial date of the time frame
	 * @param sDateFin End date of the time frame
	 * @param lsSensors List of sensors to be downloaded
	 * @param sBuildingCode Building code 
	 * @throws Exception 
	 */
	public static void downloadData(String sDateIni, String sDateFin, List<String> lsSensors, String sBuildingCode) throws Exception{
		Monitoring_Handler.hmDownloadedData = null;
		//Translation of the String into timestamp
		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd yyyy HH:mm", Locale.US);
		Timestamp tDateIni = new Timestamp(sdf.parse(sDateIni).getTime());
		Timestamp tDateEnd = new Timestamp(sdf.parse(sDateFin).getTime());

		props.clear();
		props.put("processId", "guiConnector");
		props.put("buildingId", sBuildingCode);
		props.put("startDate", tDateIni);
		props.put("finishDate", tDateEnd);
		props.put("devices", lsSensors);
		
		eventAdmin.postEvent(new Event("org/baas/dwhConnector/trigger/histDataRequest", props));
	}
	
	/**
	 * Method for logging out
	 * 
	 * @param sLogin Login of the user
	 */
	public static void logout(String sLogin, String sSession) {
		props.clear();
		props.put("processId", "guiConnector");
		props.put("userId", sLogin);
		props.put("session", sSession);
		
		eventAdmin.postEvent(new Event("org/baas/userHandler/trigger/logout", props));
		eventAdmin.postEvent(new Event("org/baas/guiConnector/trigger/logout", props));
	}	

	public static Map<String, Map<String, String>> getHmTucData() {
		return hmTucData;
	}

	public static void setHmTucData(Map<String, Map<String, String>> hmTucData) {
		Monitoring_Handler.hmTucData = hmTucData;
	}

	public static Map<String, Map<String, String>> getHmCartifData() {
		return hmCartifData;
	}

	public static void setHmCartifData(Map<String, Map<String, String>> hmCartifData) {
		Monitoring_Handler.hmCartifData = hmCartifData;
	}

	public static Map<String, Map<String, String>> getHmZubData() {
		return hmZubData;
	}

	public static void setHmZubData(Map<String, Map<String, String>> hmZubData) {
		Monitoring_Handler.hmZubData = hmZubData;
	}

	public static Map<String, Map<String, String>> getHmHusaData() {
		return hmHusaData;
	}

	public static void setHmHusaData(Map<String, Map<String, String>> hmHusaData) {
		Monitoring_Handler.hmHusaData = hmHusaData;
	}

	public static Map<String, Map<String, String>> getHmSierraData() {
		return hmSierraData;
	}

	public static void setHmSierraData(Map<String, Map<String, String>> hmSierraData) {
		Monitoring_Handler.hmSierraData = hmSierraData;
	}

	public static Map<String, Map<String, Map<String, String>>> getHmMonthTucData() {
		return hmMonthTucData;
	}

	public static void setHmMonthTucData(
			Map<String, Map<String, Map<String, String>>> hmMonthTucData) {
		Monitoring_Handler.hmMonthTucData = hmMonthTucData;
	}

	public static Map<String, Map<String, Map<String, String>>> getHmMonthCartifData() {
		return hmMonthCartifData;
	}

	public static void setHmMonthCartifData(
			Map<String, Map<String, Map<String, String>>> hmMonthCartifData) {
		Monitoring_Handler.hmMonthCartifData = hmMonthCartifData;
	}

	public static Map<String, Map<String, Map<String, String>>> getHmMonthZubData() {
		return hmMonthZubData;
	}

	public static void setHmMonthZubData(
			Map<String, Map<String, Map<String, String>>> hmMonthZubData) {
		Monitoring_Handler.hmMonthZubData = hmMonthZubData;
	}

	public static Map<String, Map<String, Map<String, String>>> getHmMonthHusaData() {
		return hmMonthHusaData;
	}

	public static void setHmMonthHusaData(
			Map<String, Map<String, Map<String, String>>> hmMonthHusaData) {
		Monitoring_Handler.hmMonthHusaData = hmMonthHusaData;
	}

	public static Map<String, Map<String, Map<String, String>>> getHmMonthSierraData() {
		return hmMonthSierraData;
	}

	public static void setHmMonthSierraData(
			Map<String, Map<String, Map<String, String>>> hmMonthSierraData) {
		Monitoring_Handler.hmMonthSierraData = hmMonthSierraData;
	}

	public static Map<String, Map<String, String>> getHmDownloadedData() {
		return hmDownloadedData;
	}

	public static void setHmDownloadedData(
			Map<String, Map<String, String>> hmDownloadedData) {
		Monitoring_Handler.hmDownloadedData = hmDownloadedData;
	}
	
}  // Autentication_Handler's end
