package com.cartif.gui.monitoring.shared;

import java.util.ArrayList;
import java.util.List;

/**
 * This class read contains the values of the BuildingCodes
 * 	 used in BimConnector bundle.  They will be read from a config file.
 * 	 This is a SingletonClass.
 * 	
 * @author BaaS Developer Team
 * @date 20140219
 */
public class BuildingCodes {
	
	static private BuildingCodes bcBuilgindCodes = null;
        
    //private static String sFICH_PROPERTIES = "./configuration/cartif.properties";	
       
	private static String sTucBuildingCode = "3SnGK6xX9DWO4W9hsuDeMF";
	private static String sZubBuildingCode = "1q80AVNS16bBczA_J1Snt3";
	private static String sCartifBuildingCode = "0X4WIUwGb0TurU_d3sNheR";
	//private static String sHusaBuildingCode = "0AuePbfAfFTx$LFOL9pMXy";
	private static String sSierraBuildingCode = "3iN1BqPX5DGe$YmokcIg7V";
		
	private static List<String> lBuildings = new ArrayList<String>();

	
	/**
	 * Private constructor because this is a singleton class  
	 */
	private BuildingCodes(){
//		lBuildings.add(sTucBuildingCode);
//    	lBuildings.add(sZubBuildingCode);
//    	lBuildings.add(sCartifBuildingCode);
//    	//lBuildings.add(sHusaBuildingCode);
//    	lBuildings.add(sSierraBuildingCode);
			
	}
	
	/**
	 * This is a singleton class, so this method is essential, because constructor is 
	 * 	not accessible from an external class
	 * 
	 */
	public static BuildingCodes getInstance(){
		lBuildings.add(sTucBuildingCode);
    	lBuildings.add(sZubBuildingCode);
    	lBuildings.add(sCartifBuildingCode);
    	//lBuildings.add(sHusaBuildingCode);
    	lBuildings.add(sSierraBuildingCode);
		
		if (bcBuilgindCodes == null){
			bcBuilgindCodes = new BuildingCodes();
		}
		return bcBuilgindCodes;
	}
	
	public static String getsTucBuildingCode() {
		return sTucBuildingCode;
	}

	public static void setsTucBuildingCode(String sTucBuildingCode) {
		BuildingCodes.sTucBuildingCode = sTucBuildingCode;
	}

	public static String getsZubBuildingCode() {
		return sZubBuildingCode;
	}

	public static void setsZubBuildingCode(String sZubBuildingCode) {
		BuildingCodes.sZubBuildingCode = sZubBuildingCode;
	}

	public static String getsCartifBuildingCode() {
		return sCartifBuildingCode;
	}

	public static void setsCartifBuildingCode(String sCartifBuildingCode) {
		BuildingCodes.sCartifBuildingCode = sCartifBuildingCode;
	}

	/*public static String getsHusaBuildingCode() {
		return sHusaBuildingCode;
	}

	public static void setsHusaBuildingCode(String sHusaBuildingCode) {
		BuildingCodes.sHusaBuildingCode = sHusaBuildingCode;
	}*/

	public static String getsSierraBuildingCode() {
		return sSierraBuildingCode;
	}

	public static void setsSierraBuildingCode(String sSierraBuildingCode) {
		BuildingCodes.sSierraBuildingCode = sSierraBuildingCode;
	}

	public static List<String> getlBuildings() {
		return lBuildings;
	}

	public static void setlBuildings(List<String> lBuildings) {
		BuildingCodes.lBuildings = lBuildings;
	}

}  // BuildingCodes end
